name = input("이름을 입력하세요: ")
number = input("학번을 입력하세요: ")
major = input("학과를 입력하세요: ")
university = input("학교를 입력하세요: ")
grade = input("학년을 입력하세요: ")

print("\n<출력>")

print("이름: ",name)
print("학번: ",number)
print("학과: ",major)
print("학교: ", university)
print("학년: ",grade)

